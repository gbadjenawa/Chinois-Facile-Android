# CHINOIS FACILE — Projet Android

Projet Android Studio prêt à compiler en APK.

## Contenu
- Application : Chinois Facile
- Version : 13.0
- Application HTML V13 intégrée dans `app/src/main/assets/index.html`
- WebView avec JavaScript et stockage local activés
- Mode portrait
- Fonctionnement hors connexion pour le contenu local

## Compiler en APK
1. Ouvrir ce dossier dans Android Studio.
2. Attendre la synchronisation Gradle.
3. Menu **Build > Build APK(s)**.
4. L'APK sera généré dans `app/build/outputs/apk/`.

Le projet utilise Android Gradle Plugin 8.7.3 et compileSdk 35.
